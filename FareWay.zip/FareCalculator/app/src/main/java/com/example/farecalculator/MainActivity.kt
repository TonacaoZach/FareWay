package com.example.farecalculator
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.common.api.Status
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var etSource: EditText
    private lateinit var etDestination: EditText
    private lateinit var textView: TextView
    private lateinit var taxiFareTextView: TextView
    private lateinit var busFareTextView: TextView
    private lateinit var carFuelCostTextView: TextView
    private lateinit var directionsbtn: Button

    private var sType: String = ""
    private var lat1 = 0.0
    private var long1 = 0.0
    private var lat2 = 0.0
    private var long2 = 0.0
    private var flag = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        directionsbtn = findViewById(R.id.directions)
        etSource = findViewById(R.id.et_source)
        etDestination = findViewById(R.id.et_destination)
        textView = findViewById(R.id.distance)
        taxiFareTextView = findViewById(R.id.taxi_fare)
        busFareTextView = findViewById(R.id.bus_fare)
        carFuelCostTextView = findViewById(R.id.car_fuel_cost)

        directionsbtn.setOnClickListener{
            val source = etSource.text.toString()
            val destination = etDestination.text.toString()
            if(source.equals("") && destination.equals("")){
                Toast.makeText(this,"Enter All Fields", Toast.LENGTH_SHORT).show()
            }
            else {
                val uri = Uri.parse("https://www.google.com/maps/dir/$source/$destination")
                val direct = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.google.android.apps.maps")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(direct)

            }
        }

        Places.initialize(applicationContext, "AIzaSyB3c0lOe49vcABflZT9sFJajFWdgT0vdAg")

        etSource.isFocusable = false
        etSource.setOnClickListener {
            sType = "source"
            val fields = listOf(Place.Field.ADDRESS, Place.Field.LAT_LNG)
            val intent = Autocomplete.IntentBuilder(
                AutocompleteActivityMode.OVERLAY, fields
            ).build(this@MainActivity)
            startActivityForResult(intent, 100)
        }

        etDestination.isFocusable = false
        etDestination.setOnClickListener {
            sType = "destination"
            val fields = listOf(Place.Field.ADDRESS, Place.Field.LAT_LNG)
            val intent = Autocomplete.IntentBuilder(
                AutocompleteActivityMode.OVERLAY, fields
            ).build(this@MainActivity)
            startActivityForResult(intent, 100)
        }

        textView.text = "0.0 Kilometers"
        taxiFareTextView.text = "Taxi Fare: AED 0.00"
        busFareTextView.text = "Bus Fare: AED 0.00"
        carFuelCostTextView.text = "Car Fuel Cost: AED 0.00"
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val place = Autocomplete.getPlaceFromIntent(data!!)
            if (sType == "source") {
                flag++
                etSource.setText(place.address)
                var sSource = place.latLng.toString()
                sSource = sSource.replace("lat/lng:", "").replace("(", "").replace(")", "")
                val split = sSource.split(",").toTypedArray()
                lat1 = split[0].toDouble()
                long1 = split[1].toDouble()
            } else {
                flag++
                etDestination.setText(place.address)
                var sDestination = place.latLng.toString()
                sDestination = sDestination.replace("lat/lng:", "").replace("(", "").replace(")", "")
                val split = sDestination.split(",").toTypedArray()
                lat2 = split[0].toDouble()
                long2 = split[1].toDouble()
            }
            if (flag >= 2) {
                calculateDistanceAndFares()
            }
        } else if (requestCode == AutocompleteActivity.RESULT_ERROR) {
            val status = Autocomplete.getStatusFromIntent(data!!)
            Toast.makeText(applicationContext, status.statusMessage, Toast.LENGTH_SHORT).show()
        }
    }

    private fun calculateDistanceAndFares() {
        val R = 6371
        val latDistance = Math.toRadians(lat2 - lat1)
        val lonDistance = Math.toRadians(long2 - long1)
        val a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        val distance = R * c
        textView.text = String.format(Locale.US, "%.2f Kilometers", distance)

        val taxiFare = distance * 1.82
        if (taxiFare < 12) {
            taxiFareTextView.text = String.format(Locale.US, "Taxi Fare: AED 12.00")
        } else {
            taxiFareTextView.text = String.format(Locale.US, "Taxi Fare: AED %.2f", taxiFare)
        }

        val busFare = distance * 0.05
        busFareTextView.text = String.format(Locale.US, "Bus Fare: AED %.2f", 2 + busFare)

        val carFuelCost = (distance / 10) * 3.34
        carFuelCostTextView.text = String.format(Locale.US, "Car Fuel Cost: AED %.2f", carFuelCost)
    }
}